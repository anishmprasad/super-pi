# Leader-Election


This is my take on [Chang and Roberts algorithm](http://en.wikipedia.org/wiki/Chang_and_Roberts_algorithm) in python. Meant to  simulate leader election to delegate jobs for distrbuted computing on Raspberry Pi's on the same subnet. Still in the process of adding features.

# Dependencies

* [Flask](http://flask.pocoo.org/)
* Python 2.9 or 3.2

# To Run

Open two terminal windows inside the Leader_election diretory. Run two instances (or more) of the application by running:

$ python LeaderElection.py

and answer the questions which follow.

Port number can be any non standard port.
Answer 'y' to start the election only once you have completed the startup process for all other instances.
